'use strict';

angular.module('tpApp.util', []);
