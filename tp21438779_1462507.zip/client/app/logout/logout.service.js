'use strict';

angular.module('tpApp')
  .service('logout', function ($rootScope) {
    $rootScope.logout = function(){
      
    }
  });
