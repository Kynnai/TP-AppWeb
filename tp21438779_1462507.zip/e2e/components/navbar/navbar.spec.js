'use strict';

var config = browser.params;

describe('Navbar View', function() {
  var page;

  beforeEach(function() {
    browser.get("/navbar");
  });



});


